
<h1 align="center">Google Home Page</h1>
<div align="center">
  <h3>
    <a href="#">
      Lenken til prosjektet
    </a>
  </h3>
</div>


<!-- TABLE OF CONTENTS -->

## Table of Contents

- [Beskrivelse](#beskrivelse)
- [Built With](#built-with)
- [Built_With](#Built With)
- [Contact](#contact)
- [Images] (#images)
- [License] (#license)

<!-- OVERVIEW -->
## Beskrivelse
Dette er prosjekte er Google Home Page. Prosjektet er laget av David, og i prosjektet er HTML og CSS brukt.

### Built With
- [HTML](https://www.w3schools.com/html/)
- [CSS](https://www.w3schools.com/css/default.asp)

## Contact
- GitHub [David er best](https://github.com/roykenvgs)
- Epost [Send meg en epost](mailto:test@gmail.com)


## images 

![Image_1](./bootstrap.png)
![Image_2](./es6.jpg)
![Image_3](./images/test.jpg)
![Image_4](./images/skjermbilde.jpg)

## License
Det er helt gratis å bruke mine koder. Hvis vil kan du spandere meg en kopp kaffe David

## Documentation
Jeg har fått hjelp av Serdar for å finne ut hvordan jeg kan bruke display flex. Deretter brukte jeg youtube videor for å lære mer om koding og slikt. Dette var det jeg gjorde for å få fram resultatet. 


## Happy coding!